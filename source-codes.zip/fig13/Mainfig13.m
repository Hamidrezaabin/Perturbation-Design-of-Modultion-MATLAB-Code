%%%%%%%%%%%Fig13,3-dimension%%%%%%%%%%%%%%%%%

clc
clear all
%%%%%%%%%%%%%%Comments%%%%%%%%%%%%%%%%%%
%Comment(1):Plase set parameters(optional)
%Comment(2):If you want to simulate with new parameters, please  insert them below;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%Parameters%%%%%%%%%%%%%%%%%
dim=3;
lambda=1e-23;
gamma=0;
T=10;
Da=10e-10;%10e-10;
Db=Da;%1.1e-10
Dc=Da; %1e-10
Th=.4;
aa=6;
r=5e-5;%5e-5;%da=0; dc=r, db=2r r=9e-4;rj=5e-5
da=[0 0 0];
db=2*r*[1 0 0];
dc=r*[1 0 0];

xmax=aa*r;
ymax=aa*r;
zmax=aa*r;
Nx=60;
Ny=60;
Nz=60;
Nt=1000;
dx=2*xmax/Nx;
dy=2*ymax/Nx;
dz=2*zmax/Nz;
dt=T/Nt;
x=-xmax:dx:xmax;
y=-ymax:dy:ymax;
z=-zmax:dz:zmax;
t=0:dt:T;

Na=5e8;
Nb=2.4e9;

sigma=10^(-5);

sx=((aa+1)/(2*aa))*Nx+1;
sy=Ny/2+1;
sz=Nz/2+1;
%%%%%%%%%%%%%%%%
rxa=Da*dt/(dx^2);
rya=Da*dt/(dy^2);
rza=Da*dt/(dz^2);

rxb=Db*dt/(dx^2);
ryb=Db*dt/(dy^2);
rzb=Db*dt/(dz^2);

rxc=Dc*dt/(dx^2);
ryc=Dc*dt/(dy^2);
rzc=Dc*dt/(dz^2);
%%%%%%%%%%%%FDM%%%%%%%%%%%%%%%%%%%%
Af=zeros(length(x),length(y),length(z),length(t));
Bf=zeros(length(x),length(y),length(z),length(t));
Cf=zeros(length(x),length(y),length(z),length(t));
%%%%%%%%initial
for ix=1:length(x)
    for iy=1:length(y)
        for iz=1:length(z)
            
            r0=[x(ix) y(iy) z(iz)];
            
   Af(ix,iy,iz,1)=Na*((1/(2*pi*sigma^2))^(3/2))*exp(-1*(1/(2*sigma^2))*(norm(r0)^2));
   Bf(ix,iy,iz,1)=Nb*((1/(2*pi*sigma^2))^(3/2))*exp(-1*(1/(2*sigma^2))*(norm(r0-db)^2));
        end
    end
end
%%%check sum
(sum(Af(:))*dx*dy*dz)/Na
(sum(Bf(:))*dx*dy*dz)/Nb
% %%%%%%%%%%%
for m=1:length(t)-1
  for i=2:length(x)-1
     for j=2:length(y)-1
        for k=2:length(z)-1
            
                
 Af(i,j,k,m+1)=Af(i,j,k,m)+rxa*(Af(i+1,j,k,m)-2*Af(i,j,k,m)+Af(i-1,j,k,m))+...
               rya*(Af(i,j+1,k,m)-2*Af(i,j,k,m)+Af(i,j-1,k,m))+...
               rza*(Af(i,j,k+1,m)-2*Af(i,j,k,m)+Af(i,j,k-1,m))+...
               dt*(-lambda*Af(i,j,k,m)*Bf(i,j,k,m)+gamma*lambda*Cf(i,j,k,m));
           
           
  Bf(i,j,k,m+1)=Bf(i,j,k,m)+rxb*(Bf(i+1,j,k,m)-2*Bf(i,j,k,m)+Bf(i-1,j,k,m))+...
               ryb*(Bf(i,j+1,k,m)-2*Bf(i,j,k,m)+Bf(i,j-1,k,m))+...
               rzb*(Bf(i,j,k+1,m)-2*Bf(i,j,k,m)+Bf(i,j,k-1,m))+...
               dt*(-lambda*Af(i,j,k,m)*Bf(i,j,k,m)+gamma*lambda*Cf(i,j,k,m)); 
           
           

 Cf(i,j,k,m+1)=Cf(i,j,k,m)+rxc*(Cf(i+1,j,k,m)-2*Cf(i,j,k,m)+Cf(i-1,j,k,m))+...
               ryc*(Cf(i,j+1,k,m)-2*Cf(i,j,k,m)+Cf(i,j-1,k,m))+...
               rzc*(Cf(i,j,k+1,m)-2*Cf(i,j,k,m)+Cf(i,j,k-1,m))+...
               dt*(+lambda*Af(i,j,k,m)*Bf(i,j,k,m)-gamma*lambda*Cf(i,j,k,m));

        end
     end
  end
end

%%%%%%%%OUT 
Cfc0=Cf(sx,sy,sz,:);
Cfc=reshape(Cfc0,length(t),1);

%%%%%%%%%%%%%%%%%%%%zero  term%%%%%%%%%%%%%%%%%
%c0=0
%%%%%%%%%%%%%%%%%%%%%first term%%%%%%%%%%%%%%%%
'just at receivers location for lambda^1'
ll=Na*Nb*lambda;
eps=.01*dt;
ta=0; tb=0;
for j=1:length(t)
    j
    ts=t(j);
       %Acent1(j)=-1*Na*Nb*oneintegralex1(Da,Da,Db,ta,tb,x(s1),t(j),eps,db);
       %Bcent1(j)=-1*Na*Nb*oneintegralex1(Db,Da,Db,ta,tb,x(s1),t(j),eps,db);
       C1(j)=ll*dimdoneintegralex1(Dc,Da,Db,ta,tb,da,db,dc,ts,eps,dim);
       
   
end




%%%%%%%%%%%%%%%%%%
kk=1;
tk=t(1:kk:end);
 Cfck=Cfc(1:kk:end);
 C1k=C1(1:kk:end);


%%%%%%%%%%%%%%%plot%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(1)
plot(tk,C1k,'b',tk,Cfck,'or')
xlabel('Time(s) ','fontsize',20,'interpreter','latex')

ylabel('$[\mathtt{C}](d_{R},t)$(molecules/m)',...
    'fontsize',20,'interpreter','latex')
 legend({'Perturbation','FDM','interpreter','latex'},...
      'interpreter','latex','interpreter','latex')
 title('Fig 13-3d dimension')




