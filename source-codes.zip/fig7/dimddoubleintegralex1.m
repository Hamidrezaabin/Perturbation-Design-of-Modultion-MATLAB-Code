function q=dimddoubleintegralex1(D5,D4,D3,D2,D1,t2,t3,t4,x2,x3,x4,x,t,eps,d)

if t<=max(t2,t3)
    q=0;
else
    
    
f1=@(t0,t1) D2.*D3.*(t1-t2).*(t1-t3)+D1.*D3.*(t0-t1).*(t1-t3)+D1.*D2.*(t0-t1).*(t1-t2);

f2=@(t0,t1) D4.*D5.*(D2.*(t1-t2)+D3.*(t1-t3)).*(t0-t4).*(t-t0)+...
            D5.*(t-t0).*f1(t0,t1)+D4.*(t0-t4).*f1(t0,t1);
        
 
 j1=@(t0,t1) f1(t0,t1)./(4.*f2(t0,t1)) ;
 j2=@(t0,t1) (D3.*D4.*(t1-t3).*(t0-t4))./(4.*f2(t0,t1));
 j3=@(t0,t1) (D2.*D4.*(t1-t2).*(t0-t4))./(4.*f2(t0,t1));
 j4=@(t0,t1) (D3.*D5.*(t1-t3).*(t-t0))./(4.*f2(t0,t1));
 j5=@(t0,t1) (D2.*D5.*(t1-t2).*(t-t0))./(4.*f2(t0,t1));
 j6=@(t0,t1) (D2.*D3.*D4.*D5.*(t1-t3).*(t1-t2).*(t-t0).*(t0-t4))./(4.*f2(t0,t1).*f1(t0,t1));
 j7=@(t0,t1) (D1.*(t0-t1))./(4.*f1(t0,t1));
           
 s=@(t0,t1) j1(t0,t1).*(norm(x-x4).^2)+j2(t0,t1).*(norm(x-x2).^2)+j3(t0,t1).*(norm(x-x3).^2)+...
            j4(t0,t1).*(norm(x2-x4).^2)+j5(t0,t1).*(norm(x3-x4).^2)+...
            (j6(t0,t1)+j7(t0,t1)).*(norm(x2-x3).^2);
  
  cond=@(t0) t0-eps;
  fun=@(t0,t1) ((1./(((4.*pi).^3).*f2(t0,t1))).^(d./2)).*exp(-1.*s(t0,t1));
  q = integral2(fun,t4+eps,t-eps,max(t2,t3)+eps,cond);
        
end
        
    
    