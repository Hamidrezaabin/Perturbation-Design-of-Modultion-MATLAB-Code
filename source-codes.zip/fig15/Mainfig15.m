%function concentration(lambda)
%lambda=1e-22;
%aa=num2str(lambda);
%mkdir(aa)
clc
clear all
global Na
global Nb
global da
global db
global Da
global Db
global Dc
global lambda
global sigma
global gamma
load Dcfig15 Dcfig15

for iii=1:1:length(Dcfig15)
    
   
  
lambda=1e-22;
gamma=0;


Da=10e-10;
Db=10e-10;
Dc=Dcfig15(iii);
ii=11;
r=5e-5;
da=0;
db=2*r;
dc=r;
aa=6;
xmax=aa*r;
Na=5e8;
Nb=2.4e9;
Nx=60; 
deltax=2*xmax/Nx;
x=-xmax:deltax:xmax;
sigma=10^(-5);
T=30;
Nt=3*1000;
deltat=T/Nt;
j=201;
t=0:deltat:T;
m=length(x);
n=length(t);
s1=((aa+1)/(2*aa))*Nx+1;
sol = pdepe(0,@pdex4pde,@pdex4ic,@pdex4bc,x,t);
solc=sol(:,:,3);
solc=solc';
eps=.01*deltat;
ta=0; tb=0;

test=1;
th=.05;
while test==1
    

       Ccent1(j)=lambda*Na*Nb*oneintegralex1(Dc,Da,Db,ta,tb,x(s1),t(j),eps,db);
       er=abs(solc(s1,j)-Ccent1(j))/(abs(solc(s1,j)));
       er(isnan(er))=0;
       j=j+1;
       if j>length(t)
           test=0;
       end
       
       if er==th
           test=0;
           maxt(iii)=t(j-1);
       end
       
       if er>th&&j==2
           test=0; 
           maxt(iii)=t(j-1);
       end
       
       if er>th&&j>2
           test=0; 
           maxt(iii)=(t(j-1)+t(j-2))/2;
       end
       
       
   
end
end
% maxt2=[maxt1,maxt];

H=figure(1);
plot(Dcfig15,maxt,'b')
grid on
xlabel('$D_{\mathtt{C}}(m^{2}.s^{-1})$','fontsize',20,'interpreter','latex')
ylabel('Permissible Time Interval(s)',...
    'fontsize',20,'interpreter','latex')

