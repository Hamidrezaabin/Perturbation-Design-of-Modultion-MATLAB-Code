%%%%%%%%%%%%%%%%%Fig 12-2d dimension%%%%%%%%%%%%%%%%%%%%
clc
clear all
%%%%%%%%%%%%%%Comments%%%%%%%%%%%%%%%%%%
%Comment(1):Plase set parameters(optional)
%Comment(2):If you want to simulate with new parameters, please  insert them below;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dim=2;
lambda=1e-23;
gamma=0;
T=10;
Da=10e-10;
Db=Da;
Dc=Da; 
Th=.1;
aa=6;
r=5e-5;%5e-5;%da=0; dc=r, db=2r r=9e-4;rj=5e-5
da=[0 0];
db=2*r*[1 0];
dc=r*[1 0];

xmax=aa*r;
ymax=aa*r;
Nx=60;
Ny=60;
Nt=1000;
dx=2*xmax/Nx;
dy=2*ymax/Nx;
dt=T/Nt;
x=-xmax:dx:xmax;
y=-ymax:dy:ymax;
t=0:dt:T;

Na=5e8;
Nb=2.4e9;

sigma=10^(-5.1);

sx=((aa+1)/(2*aa))*Nx+1;
sy=Ny/2+1;
%%%%%%%%%%%%%%%%
rxa=Da*dt/(dx^2);
rya=Da*dt/(dy^2);

rxb=Db*dt/(dx^2);
ryb=Db*dt/(dy^2);

rxc=Dc*dt/(dx^2);
ryc=Dc*dt/(dy^2);

%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%FDM%%%%%%%%%%%%%%%%%%%%
Af=zeros(length(x),length(y),length(t));
Bf=zeros(length(x),length(y),length(t));
Cf=zeros(length(x),length(y),length(t));
%%%%%%%%initial
for ix=1:length(x)
    for iy=1:length(y)
        
            
            r0=[x(ix) y(iy)];
            
   Af(ix,iy,1)=Na*((1/(2*pi*sigma^2)))*exp(-1*(1/(2*sigma^2))*(norm(r0)^2));
   Bf(ix,iy,1)=Nb*((1/(2*pi*sigma^2)))*exp(-1*(1/(2*sigma^2))*(norm(r0-db)^2));
        end
end

%%%%%%%%%%%
for m=1:length(t)-1
  for i=2:length(x)-1
     for j=2:length(y)-1
        
            
                
 Af(i,j,m+1)=Af(i,j,m)+rxa*(Af(i+1,j,m)-2*Af(i,j,m)+Af(i-1,j,m))+...
               rya*(Af(i,j+1,m)-2*Af(i,j,m)+Af(i,j-1,m))+...
               dt*(-lambda*Af(i,j,m)*Bf(i,j,m)+gamma*lambda*Cf(i,j,m));
           
           
   Bf(i,j,m+1)=Bf(i,j,m)+rxb*(Bf(i+1,j,m)-2*Bf(i,j,m)+Bf(i-1,j,m))+...
               ryb*(Bf(i,j+1,m)-2*Bf(i,j,m)+Bf(i,j-1,m))+...
               dt*(-lambda*Af(i,j,m)*Bf(i,j,m)+gamma*lambda*Cf(i,j,m));
           
           

  Cf(i,j,m+1)=Cf(i,j,m)+rxc*(Cf(i+1,j,m)-2*Cf(i,j,m)+Cf(i-1,j,m))+...
               ryc*(Cf(i,j+1,m)-2*Cf(i,j,m)+Cf(i,j-1,m))+...
               dt*(+lambda*Af(i,j,m)*Bf(i,j,m)-gamma*lambda*Cf(i,j,m));

        end
     end
end

%%%%%%%%OUT 
%%%%%%%%OUT 
Cfc0=Cf(sx,sy,:);
Cfc=reshape(Cfc0,1,length(t));
%%%%%%%%%%%%%%%%%%%%zero  term%%%%%%%%%%%%%%%%%
ll=(Na*Nb)*lambda;
eps=.01*dt;
ta=0; tb=0;
for j=1:length(t)
    j
    ts=t(j);
       %Acent1(j)=-1*Na*Nb*oneintegralex1(Da,Da,Db,ta,tb,x(s1),t(j),eps,db);
       %Bcent1(j)=-1*Na*Nb*oneintegralex1(Db,Da,Db,ta,tb,x(s1),t(j),eps,db);
       C1(j)=ll*dimdoneintegralex1(Dc,Da,Db,ta,tb,da,db,dc,ts,eps,dim);
end
%%%%%%%%%%%%%%%%%%%%%%%%%
kk=50;
tk=t(1:kk:end);
 Cfck=Cfc(1:kk:end);
 C1k=C1(1:kk:end);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
 figure(1)
plot(tk,C1k,'b',tk,Cfck,'or')
xlabel('Time(s) ','fontsize',20,'interpreter','latex')

ylabel('$[\mathtt{C}](d_{R},t)$(molecules/m)',...
    'fontsize',20,'interpreter','latex')
 legend({'Perturbation','FDM','interpreter','latex'},...
      'interpreter','latex','interpreter','latex')
 title('Fig 12-2d dimension')