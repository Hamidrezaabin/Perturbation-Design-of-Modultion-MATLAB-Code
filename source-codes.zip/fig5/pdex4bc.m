function [pl,ql,pr,qr] = pdex4bc(xl,ul,xr,ur,t)
pl = [ul(1); ul(2);ul(3)]; 
ql = [0; 0;0]; 
pr =[ur(1); ur(2);ur(3)]; 
qr = [0; 0;0]; 
