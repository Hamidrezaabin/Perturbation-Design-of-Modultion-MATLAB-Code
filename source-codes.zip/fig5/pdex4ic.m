function u0 = pdex4ic(x)
global Na
global Nb
global da
global db
global Da
global Db
global Dc
global lambda
global sigma



% sigma=10^(-5);
% Na=5e8;%5e4; %5e6        5e8
% Nb=2.4e9;%
% da=0;
% db=10^(-4);
uu1=(Na/(sqrt(2*pi*sigma^2))).*exp(-((x-da)^2)./(2*sigma^2));
uu2=(Nb/(sqrt(2*pi*sigma^2))).*exp(-((x-db)^2)./(2*sigma^2));
u0 = [uu1;uu2;0];








