%%%%%%%%%%%%Figure 5-first set of parameters%%%%%%%%%%%%%%%%%%%%%%%
clc
clear all
%%%%%%%%%%%%%%Comments%%%%%%%%%%%%%%%%%%
%Comment(1):Plase set parameters(optional)
%Comment(2):If you want to simulate with new parameters, please  insert them below;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global Na
global Nb
global da
global db
global Da
global Db
global Dc
global lambda
global sigma
global gamma
%%%%%%%%%%%%%%%%%%%Parameters%%%%%%%%%%%%%%%%%%%%%
lambda=1e-22;
gamma=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Da=1e-9;
Db=7e-10;
Dc=1e-10;
%%%%%%%%%%%%%%%%%%%%%
dim=1;
%%%%%%%%%%%%%%%%%%%%%%%
r=5e-5;
da=0;
db=2*r;
dc=r;
%%%%%%%%%%%%%%%%%%%%%%%%%%
aa=6;
xmax=aa*r;
Nx=60; %120,192
deltax=2*xmax/Nx;
x=-xmax:deltax:xmax;
s1=((aa+1)/(2*aa))*Nx+1;
%%%%%%%%%%Time%%%%%%%%%
T=10;
Nt=1000;
deltat=T/Nt;
t=0:deltat:T;
ta=0;
tb=0;
%%%%%%%%%%%%%%%Number of molecules%%%%%%%%%%%%
%%%%%%%%%%%%
Na=5e8;
Nb=2.4e9;

ll=(Na*Nb)*lambda;
%%%%%%%%%%%%%%%%First order%%%%%%%%%%%%%%%%%%%
sigma=10^(-5);
eps=10^(-8);% avoiding non singular integral, eps should be a positive small real number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=11:length(t) %genration densiteis for all t
        C1(i)=ll*dimdoneintegralex1(Dc,Da,Db,ta,tb,da,db,dc,t(i),eps,dim); 
end
%%%%%%%%%%%%%%%%FDM%%%%%%%%%%%%%%%%%%%
sol = pdepe(0,@pdex4pde,@pdex4ic,@pdex4bc,x,t);
solc=sol(:,:,3);
solc=solc';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
kk=25;% number of sample points
tk=t(1:kk:end);
C1k=C1(1:kk:end);
solck=solc(s1,1:kk:end);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
plot(tk,C1k,'b',tk,solck,'or')
xlabel('Time(s) ','fontsize',20,'interpreter','latex')

ylabel('$[\mathtt{C}](d_{R},t)$(molecules/m)',...
    'fontsize',20,'interpreter','latex')
 legend({'Perturbation','FDM','interpreter','latex'},...
      'interpreter','latex','interpreter','latex')
 title('Fig 5')