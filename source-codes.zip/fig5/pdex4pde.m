function [c,f,s] = pdex4pde(x,t,u,DuDx)
global Na
global Nb
global da
global db
global Da
global Db
global Dc
global lambda

% Da=10e-10;%10e-10; above equation ==main
% Db=9e-10;%1.1e-10;%(40/40)*Da;%1.1e-10,1.125e-9
% Dc=1e-10;%(40/40)*Da; %1e-10,1.2e-9
% lambda=1e-22;
c=[1;1;1];
f=[Da;Db;Dc].*DuDx;
s=lambda.*[-1;-1;1].*(u(1).*u(2));
end



