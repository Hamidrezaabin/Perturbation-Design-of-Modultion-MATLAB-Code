%%%%%%%%%%%%Figure 2%%%%%%%%%%%%%%%%%%%%%%%
clc
clear all
%%%%%%%%%%%%%%Comments%%%%%%%%%%%%%%%%%%
%Comment(1):Plase set parameters(optional)
%Comment(2):If you want to simulate with new parameters, please  set new=1 and import S1;
%Comment(3):S1=time axis={s},%%s=sa=sb;
%Comment(4): If you want to simulate in other dimension, change dim
%            and in plot section(ordinary&log scale plot) import number of dim in xlabel, 
%            m^3--->m^{dim}(m^{import number of dim}).
%xlabel('Molecules/(m^3) )',...)---->
%--->xlabel('Molecules/(m^{import number of dim}) )',...)
%%%%%%%%%%%PARAMETERS%%%%%%%%%%%%%%%%%%
lambda=1e-23;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Da=10e-10;
Db=Da;
Dc=Da;
%%%%%%%%%%%%%%%%%%%%%
dim=3;%Comment(4)
%%%%%%%%%%%%%%%%%%%%%%%
r=5e-5;
da=[0 0 0];
db=2*r*[1 0 0];
dc=r*[1 0 0];
%%%%%%%%%%%%%%%%%%%%%
T=3;
nt=3;
Deltat=T/nt;
ts=0:Deltat:T-Deltat;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
volume=10^(-11);%%%%V=volume,poiss(V\rho)
volumehamid=volume;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eps=10^(-8);% avoiding non singular integral, eps should be a positive small real number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
new=0;
%%%%%%%%%%%loading%%%%%%%%%%%%%%

load Sfig3 Sfig3% in the paper
%S1=[-,-,....,-];% 
%please import S1(as an increasing sequence) and romeve the comment,
%if you want simulate with new parameters
%parameters, 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%END OF Parameters%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%conditions%%%%%%%%%%%%%%%%%%%%%
lb=zeros(8,1);
AA=condions1;
%%%%%%%%%%%%%%%%%%%%%%%%%
M=permn2(length(ts),8);
Niter =size(M,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if new==0
    S=Sfig3;
end

if new==1
    S=S1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    G=zeros(length(ts),length(ts));
for i=11:length(ts) %genration densiteis for all t
    for j=11:length(ts)
        ta=ts(i1);
        tb=ts(j1);
        G(i1,j1)=lambda*dimdoneintegralex1(Dc,Da,Db,ta,tb,da,db,dc,T,eps,dim);
    end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(S)
    Sa=S(j);
    Sb=Sa;
    b=[Sa;Sa;Sb;Sb];
   
   
  
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   parfor i=1:Niter
       
    disp(['i: ',num2str(i), ' of ', num2str(Niter)]);
    fun=@(x)objective22(x,i,G,M,volumehamid);        
    [xsol,fval] =ga(fun,8,AA,b,[],[],lb,[],[],[]);
    Gxf(i,:)=[xsol,fval];
   end
fvaluedelta=Gxf(:,9);
pedelta(j)=min(fvaluedelta);
end


%%%%%%%%%%%%%%%%%ordinary plot%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
plot(S,pedelta,'b')
xlabel('s(molecules/(m^3) ))','fontsize',20,'interpreter','latex')
% above Comment(4)
ylabel('Error Probability',...
    'fontsize',20,'interpreter','latex')
%  legend({'Pulse Family','OPtimal Wave-Form','interpreter','latex'},...
%       'interpreter','latex','interpreter','latex')
 title('Fig 3')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%log scale%%%%%%%%%%%%%%%%%%%%%%%%%%
k=length(find(pedelta~=0));% avoiding: log0=infinity% k: number of nonzero elements
%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2)
loglog(S(1:k),pedelta(1:k),'b')
grid on 
xlabel('s(molecules/(m^3)) )','fontsize',20,'interpreter','latex')
% above Comment(4)
ylabel('Error Probability',...
    'fontsize',20,'interpreter','latex')
%  legend({'Pulse Family','OPtimal Wave-Form','interpreter','latex'},...
%       'interpreter','latex','interpreter','latex')
 title('Fig 3-log scale')


%%%%%%%%%%%%%%%%%%%%%%%%%%END%%%%%%%%%%%%%%%%%%%%%