%%%%%%%%%%%%Figure 8&9-Second set of parameters%%%%%%%%%%%%%%%%%%%%%%%
clc
clear all
%%%%%%%%%%%%%%Comments%%%%%%%%%%%%%%%%%%
%Comment(1):Plase set parameters(optional)
%Comment(2):If you want to simulate with new parameters, please  insert them below;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global Na
global Nb
global da
global db
global Da
global Db
global Dc
global lambda
global sigma
global gamma
%%%%%%%%%%%%%%%%%%%Parameters%%%%%%%%%%%%%%%%%%%%%
for l=1:8
lambdalist2(l)=10^(-22+l);
end
for i=1:length(lambdalist2)
    lambda=lambdalist2(i);

gamma=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Da=1e-9;
Db=1e-9;
Dc=1e-9;
%%%%%%%%%%%%%%%%%%%%%
dim=1;
%%%%%%%%%%%%%%%%%%%%%%%
r=5e-5;
da=0;
db=2*r;
dc=r;
%%%%%%%%%%%%%%%%%%%%%%%%%%
aa=6;
xmax=aa*r;
Nx=60; %120,192
deltax=2*xmax/Nx;
x=-xmax:deltax:xmax;
s1=((aa+1)/(2*aa))*Nx+1;
%%%%%%%%%%Time%%%%%%%%%
T=10;
Nt=1000;
deltat=T/Nt;
t=0:deltat:T;
ta=0;
tb=0;
%%%%%%%%%%%%%%%Number of molecules%%%%%%%%%%%%
%%%%%%%%%%%%
Na=5e8;
Nb=2.4e9;


%%%%%%%%%%%%%%%%First order%%%%%%%%%%%%%%%%%%%
sigma=10^(-5);
eps=.01*deltat;% avoiding non singular integral, eps should be a positive small real number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%
sol = pdepe(0,@pdex4pde,@pdex4ic,@pdex4bc,x,t);
solc=sol(:,:,3);
solc=solc';
%%%%%%%%%%%%%%%firt-order%%%%%%%%%%%%%%%%%%





 C1=lambda*Na*Nb*dimdoneintegralex1(Dc,Da,Db,ta,tb,da,db,dc,T,eps,dim);
 qc1=-1*(Na^2)*Nb*dimddoubleintegralex1(Dc,Da,Db,Da,Db,0,0,0,da,db,da,dc,T,eps,dim);
 qc2=-1*(Nb^2)*Na*dimddoubleintegralex1(Dc,Db,Da,Da,Db,0,0,0,da,db,db,dc,T,eps,dim);
 C2=C1+(lambda^2)*(qc1+qc2);
  
       er2(i)=abs(solc(s1,end)-C2)/(abs(solc(s1,end)));
       er2(isnan(er2(i)))=0;
       
end
%%%%%%%%%%%%%%%%%%%%%%%
p1=find(er2~=0);
k=p1(1);
semilogx(lambdalist2(k:end),er2(k:end),'b')
grid on 
xlabel('$\lambda(molecules^{-1}.m.s^{-1}) $','fontsize',20,'interpreter','latex')
% above Comment(4)
ylabel('Relative error',...
    'fontsize',20,'interpreter','latex')
%  legend({'Pulse Family','OPtimal Wave-Form','interpreter','latex'},...
%       'interpreter','latex','interpreter','latex')
 title('Fig 9-log scale')

