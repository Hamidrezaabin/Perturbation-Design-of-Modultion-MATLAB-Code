function q2=dimdpulsefirstorder(Da,Db,Dc,T,xd,xb,eps,d)

f2=@(t1,u1,u2) Da.*Dc.*(u1).*(T-t1)+Db.*Dc.*(u2).*(T-t1)+Da.*Db.*(u1).*(u2);
gamma1=@(t1,u1,u2) (Da.*(u1))./(4.*f2(t1,u1,u2));
gamma2=@(t1,u1,u2) (Db.*(u2))./(4.*f2(t1,u1,u2));
gamma3=@(t1,u1,u2) (Dc.*(T-t1))./(4.*f2(t1,u1,u2));
f3=@(t1,u1,u2) gamma1(t1,u1,u2).*(norm(xb-xd).^2)+...
    gamma2(t1,u1,u2).*(norm(xd)^2)+gamma3(t1,u1,u2).*(norm(xb)^2);
I1=@(t1,u1,u2) exp((-1).*f3(t1,u1,u2));
I2=@(t1,u1,u2) ((4.*pi).^(d)).*((f2(t1,u1,u2)).^(d/2));
If=@(t1,u1,u2) I1(t1,u1,u2)./(I2(t1,u1,u2));

xmin = eps;
xmax = T-eps;
ymin =eps;
ymax = @(t1) t1-eps;
zmin =eps;
zmax = @(t1,u2) t1-eps;
%dzdydx==du1*du2*dt1
q2=integral3(If,xmin,xmax,ymin,ymax,zmin,zmax,'AbsTol', 0,'RelTol',1e-9);
    