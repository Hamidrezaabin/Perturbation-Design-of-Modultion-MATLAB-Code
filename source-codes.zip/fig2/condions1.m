function AA=condions1
% global numberhamid
numberhamid=8;
if numberhamid==9
AA=zeros(4,numberhamid);
AA(1,1)=1;
AA(1,2)=1;
AA(2,3)=1;
AA(2,4)=1;
AA(3,5)=1;
AA(3,6)=1;
AA(4,7)=1;
AA(4,8)=1;
AA(4,9)=1;
end
if numberhamid==8
AA=zeros(4,numberhamid);
AA(1,1)=1;
AA(1,2)=1;
AA(2,3)=1;
AA(2,4)=1;
AA(3,5)=1;
AA(3,6)=1;
AA(4,7)=1;
AA(4,8)=1;
end
