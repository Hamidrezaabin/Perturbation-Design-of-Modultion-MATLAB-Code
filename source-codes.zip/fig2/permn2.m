function M=permn2(k,number)
%number=8 or 9
if number==9
M=zeros(1,number);
for i1=1:k
for i2=i1:k
for i3=1:k 
for i4=i3:k
for i5=1:k
for i6=i5:k
for i7=1:k
for i8=i7:k
for i9=i8:k
    y=[i1,i2,i3,i4,i5,i6,i7,i8,i9];
    M=[M;y];
end
end
end
end
end
end
end
end
end
M(1,:)=[];
% save(fullfile('D:\Abin\numericalex1\modulation\ex1',aa2,'M'),'M')
end
if number==8
   M=zeros(1,number);
for i1=1:k-1
for i2=i1+1:k
for i3=1:k-1 
for i4=i3+1:k
for i5=1:k-1
for i6=i5+1:k
for i7=1:k-1
for i8=i7+1:k

    y=[i1,i2,i3,i4,i5,i6,i7,i8];
    M=[M;y];
end
end
end
end
end
end
end
end
end
M(1,:)=[];
%M1=M;
%4:1296,5=10000;6=50625
%save M M
% save(fullfile('D:\Abin\numericalex1\modulation\ex1',aa2,'M'),'M')
save M M
%save Gxf Gxf

end 