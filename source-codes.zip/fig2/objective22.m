

function yy=objective22(x,i3,G,M,volumehamid)

% global i3
% i3
% disp(['i: ',num2str(i3), ' of ', num2str(Niter)]);

N=M(i3,:);

GG=G;%G=G4
 gg=[GG(N(1),N(5)),GG(N(1),N(6)),GG(N(1),N(7)),GG(N(1),N(8)),...
    GG(N(2),N(5)),GG(N(2),N(6)),GG(N(2),N(7)),GG(N(2),N(8)),...
    GG(N(3),N(5)),GG(N(3),N(6)),GG(N(3),N(7)),GG(N(3),N(8)),...
   GG(N(4),N(5)),GG(N(4),N(6)),GG(N(4),N(7)),GG(N(4),N(8))]...
  ;
g=gg;

a=[x(1),x(2)];%
 b=[x(3),x(4)];
 c=[x(5),x(6)];
 d=[x(7),x(8)];
 A1=a(1)*g(1)*c(1)+a(1)*g(2)*c(2)+a(2)*g(5)*c(1)+a(2)*g(6)*c(2);%00
 B1=a(1)*g(3)*d(1)+a(1)*g(4)*d(2)+a(2)*g(7)*d(1)+a(2)*g(8)*d(2);%01
 C1=b(1)*g(9)*c(1)+b(1)*g(10)*c(2)+b(2)*g(13)*c(1)+b(2)*g(14)*c(2);%10
 D1=b(1)*g(11)*d(1)+b(1)*g(12)*d(2)+b(2)*g(15)*d(1)+b(2)*g(16)*d(2);%11
 l=volumehamid*[A1,B1,C1,D1];
 A=min(l);
 l1=find(l==A);
 l(l1(1))=[];
 B=min(l);
 l1=find(l==B);
 l(l1(1))=[];
 C=min(l);
 D=max(l);
 
 qq=[A,B,C,D];

  An=length(find(qq==A));
  Bn=length(find(qq==B));
  Cn=length(find(qq==C));
  Dn=length(find(qq==D));

 T1=(B-A)./log(B/A);
 T1(isnan(T1))=A;
 T2=(C-B)./log(C/B);
 T2(isnan(T2))=B;
 T3=(D-C)./log(D/C);
 T3(isnan(T3))=C;
  T11=floor(T1)+1-(floor(T1)==T1);
  T22=floor(T2)+1-(floor(T2)==T2);
  T33=floor(T3)+1-(floor(T3)==T3);
  aa=[An,Bn,Cn,Dn];
  
  %%%%%%%%%%%%%%%%%%%%%case1:0 A B C D%%%%%%%%%%%% 
  if A>0 && norm((aa-[1,1,1,1]),1)==0
      peA=1-poisscdf(max(T11-1,0),A);
      peB=poisscdf(max(T11-1,0),B)+1-poisscdf(max(T22-1,0),B);
      peC=poisscdf(max(T22-1,0),C)+1-poisscdf(max(T33-1,0),C);
      peD=poisscdf(max(T33-1,0),D);
      
      %%%%%%%%%%%%%%%%%%%%%case2:0 B C D%%%%%%%%%%%% 
  elseif  A==0&& norm((aa-[1,1,1,1]),1)==0
      peA=0;
      peB=poisscdf(0,B)+1-poisscdf(max(T22-1,0),B);
      peC=poisscdf(max(T22-1,0),C)+1-poisscdf(max(T33-1,0),C);
      peD=poisscdf(max(T33-1,0),D);
      
       %%%%%%%%%%%%%%%%%%%%%case3:0 0 C D%%%%%%%%%%%% 
   elseif  A==0&& norm((aa-[2,2,1,1]),1)==0 
      peA=.5;
      peB=.5;
      peC=poisscdf(max(T22-1,0),C)+1-poisscdf(max(T33-1,0),C);
      peD=poisscdf(max(T33-1,0),D);
      
       %%%%%%%%%%%%%%%%%%%%%case4:0 0 CD%%%%%%%%%%%% 
   elseif  A==0&& C>0 && norm((aa-[2,2,2,2]),1)==0 
      peA=.5;
      peB=.5;
      peC=(1+exp(-C))*(.5);
      peD=peC;
       %%%%%%%%%%%%%%%%%%%%%case5:0 0 0 D%%%%%%%%%%%% 
   elseif  A==0&& D>0 && norm((aa-[3,3,3,1]),1)==0 
      peA=2/3;
      peB=2/3;
      peC=2/3;
      peD=exp(-D);
      
     %%%%%%%%%%%%%%%%%%%%%case6:0 0 0 0%%%%%%%%%%%% 
   elseif  A==0&& norm((aa-[4,4,4,4]),1)==0 
      peA=3/4;
      peB=3/4;
      peC=3/4;
      peD=3/4;
       %%%%%%%%%%%%%%%%%%%%%case7:0 AB C D%%%%%%%%%%%% 
  elseif A>0 && norm((aa-[2,2,1,1]),1)==0
      peA=1-.5*poisscdf(max(T22-1,0),A);
      peB=peA;
      peC=poisscdf(max(T22-1,0),C)+1-poisscdf(max(T33-1,0),C);
      peD=poisscdf(max(T33-1,0),D);
       %%%%%%%%%%%%%%%%%%%%%case8:0 AB CD%%%%%%%%%%%% 
  elseif A>0 && norm((aa-[2,2,2,2]),1)==0
      peA=1-.5*poisscdf(max(T22-1,0),A);
      peB=peA;
      peC=.5*(1+poisscdf(max(T22-1,0),C));
      peD=peC;
      
      %%%%%%%%%%%%%%%%%%%%%case9:0 A B CD%%%%%%%%%%%% 
  elseif A>0 && norm((aa-[1,1,2,2]),1)==0
       peA=1-poisscdf(max(T11-1,0),A);
      peB=poisscdf(max(T11-1,0),B)+1-poisscdf(max(T22-1,0),B);
      peC=.5*(1+poisscdf(max(T22-1,0),C));
      peD=peC;
      %%%%%%%%%%%%%%%%%%%%%case10:0 A BC D%%%%%%%%%%%% 
  elseif A>0 && norm((aa-[1,2,2,1]),1)==0
      peA=1-poisscdf(max(T11-1,0),A);
      xb=poisscdf(max(T11-1,0),B)+1-poisscdf(max(T22-1,0),B);
      peB=.5+.5*xb;
      peC=peB;
      peD=poisscdf(max(T33-1,0),D);
       %%%%%%%%%%%%%%%%%%%%%case11:0 A   BCD%%%%%%%%%%%% 
  elseif A>0 && norm((aa-[1,3,3,3]),1)==0
      peA=1-poisscdf(max(T11-1,0),A);
      xb=poisscdf(max(T11-1,0),B);
      peB=(2/3)+(1/3)*xb;
      peC=peB;
      peD=peC;
      
        %%%%%%%%%%%%%%%%%%%%%case12:0 ABC  D%%%%%%%%%%%% 
  elseif A>0 && norm((aa-[3,3,3,1]),1)==0
      xa=1-poisscdf(max(T33-1,0),B);
      peA=(2/3)+(1/3)*xa;
      peB=peA;
      peC=peB;
      peD=poisscdf(max(T33-1,0),D);
      
       %%%%%%%%%%%%%%%%%%%%%case13:0 ABCD%%%%%%%%%%%% 
  else A>0 && norm((aa-[4,4,4,4]),1)==0
      
      peA=3/4;
      peB=3/4;
      peC=3/4;
      peD=3/4;
      
  end
  yy=.25*(peA+peB+peC+peD);

 
     
 