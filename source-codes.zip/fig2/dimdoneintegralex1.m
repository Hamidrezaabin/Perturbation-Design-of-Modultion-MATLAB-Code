function q=dimdoneintegralex1(D1,D2,D3,t2,t3,x2,x3,x,t,eps,d)
%x=xs t=ts t1=integral variable
%phi_1**(phi2(x-x2,t-t2)\times phi3(x-x3,t-t3))

if t<=max(t2,t3)
    q=0;
else
f1=@(t1) D2.*D3.*(t1-t2).*(t1-t3)+D1.*D3.*(t-t1).*(t1-t3)+D1.*D2.*(t-t1).*(t1-t2);

s=@(t1) (D3.*(t1-t3)./(4.*f1(t1))).*(norm(x2-x).^2)+...
        (D1.*(t-t1)./(4.*f1(t1))).*(norm(x2-x3).^2)+...
        (D2.*(t1-t2)./(4.*f1(t1))).*(norm(x-x3).^2);
    
   
 fun=@(t1) ((1./(((4.*pi).^2).*f1(t1))).^(d./2)).*(exp(-1.*s(t1)));
 q = integral(fun,max(t2,t3)+eps,t-eps);
end