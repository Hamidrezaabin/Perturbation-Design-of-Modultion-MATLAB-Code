%%%%%%%%%%%%Figure 5-first set of parameters%%%%%%%%%%%%%%%%%%%%%%%
clc
clear all
%%%%%%%%%%%%%%Comments%%%%%%%%%%%%%%%%%%
%Comment(1):Plase set parameters(optional)
%Comment(2):If you want to simulate with new parameters, please  insert them below;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global Na
global Nb
global da
global db
global Da
global Db
global Dc
global lambda
global sigma
global gamma
Dclist=(1e-10)*[1,2,3,4,5];
for iii=1:length(Dclist)
%%%%%%%%%%%%%%%%%%%Parameters%%%%%%%%%%%%%%%%%%%%%
lambda=1e-16;
gamma=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Da=10e-10;
Db=10e-10;
Dc=Dclist(iii);
%%%%%%%%%%%%%%%%%%%%%
dim=1;
%%%%%%%%%%%%%%%%%%%%%%%
r=5e-5;
da=0;
db=2*r;
dc=r;
%%%%%%%%%%%%%%%%%%%%%%%%%%
aa=6;
xmax=aa*r;
Nx=60; %120,192
deltax=2*xmax/Nx;
x=-xmax:deltax:xmax;
s1=((aa+1)/(2*aa))*Nx+1;
%%%%%%%%%%Time%%%%%%%%%
T=10;
Nt=1000;
deltat=T/Nt;
t=0:deltat:T;
ta=0;
tb=0;
%%%%%%%%%%%%%%%Number of molecules%%%%%%%%%%%%
%%%%%%%%%%%%
Na=5e8;
Nb=2.4e9;

ll=(Na*Nb)*lambda;
%%%%%%%%%%%%%%%%First order%%%%%%%%%%%%%%%%%%%
sigma=10^(-5);
eps=10^(-8);% avoiding non singular integral, eps should be a positive small real number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:length(t) %genration densiteis for all t
        C1(iii,i)=ll*dimdoneintegralex1(Dc,Da,Db,ta,tb,da,db,dc,t(i),eps,dim); 
end
%%%%%%%%%%%%%%%%FDM%%%%%%%%%%%%%%%%%%%
sol = pdepe(0,@pdex4pde,@pdex4ic,@pdex4bc,x,t);
solc=sol(:,:,3);
solc=solc';
solcf(iii,:)=solc(s1,:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
kk=25;% number of sample points
j=1:kk:length(t);
tk=t(j);
% C1k=C1(1:kk:end);
% solck=solc(s1,1:kk:end);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
plot(tk,C1(1,j),'b',tk,solcf(1,j),'ok',...
   tk,C1(2,j),'r',tk,solcf(2,j),'*k',...
   tk,C1(3,j),'g',tk,solcf(3,j),'ok',...
  tk,C1(4,j),'y',tk,solcf(4,j),'*k',...
 tk,C1(5,j),'b',tk,solcf(5,j),'ok')
xlabel('Time(s) ','fontsize',20,'interpreter','latex')

ylabel('$[\mathtt{C}](d_{R},t)$(molecules/m)',...
    'fontsize',20,'interpreter','latex')
%  legend({'Perturbation','FDM','interpreter','latex'},...
%       'interpreter','latex','interpreter','latex')
 title('Fig 14')